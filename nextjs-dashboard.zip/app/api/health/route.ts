export function GET(request: Request) {
  return new Response("System is operational", { status: 200 })
}

